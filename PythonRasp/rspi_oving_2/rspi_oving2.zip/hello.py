from sense_hat import SenseHat

senseHat = SenseHat()

while True:
    senseHat.show_message("Hello world!")
