from sense_hat import SenseHat

sense = SenseHat()

sense.set_pixel(0, 0, 255, 0,255)
